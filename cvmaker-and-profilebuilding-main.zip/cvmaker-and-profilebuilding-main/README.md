# cvmaker-and-profilebuilding
OVERVIEW:
Web application to add and store your accomplishments to build a profile for professional work.
Users are expected to create an account inorder to use the services.After creating account users must fill their profile details and add certifications for the respective courses and achievements.
Consolidated view of accomplishments along with graphical analysis will be provided to the user so that user can keep track of their progress.
After completing the profile users can generate resumes with the template of their choice in the pdf format.

TOOLS USED:
 Mysql database form Xampp server.
 PDF generation from php library Dompdf.
 Graphs from javascript library Morris.js
 Front end framework Bootstrap and jquery.
 
 DEMO LINK:
   https://drive.google.com/file/d/10NK2TNuWs1fBDwHoGIOek8M80XkFE6Gp/view?usp=sharing
   
DONE BY : Rahul C K , Lohith Sowmiyan P S
